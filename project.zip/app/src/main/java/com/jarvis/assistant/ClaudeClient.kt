package com.jarvis.assistant

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Cerebro de Jarvis. Detecta el proveedor por la clave:
 * - empieza por "sk-ant" -> Claude (Anthropic, de pago)
 * - cualquier otra (AIza...) -> Gemini (Google AI Studio, con capa gratis)
 */
object ClaudeClient {

    const val CLAUDE_MODEL = "claude-sonnet-5-5"
    const val GEMINI_MODEL = "gemini-3.8-flash"

    fun ask(apiKey: String, system: String, history: List<Pair<String, String>>): String =
        if (apiKey.startsWith("sk-ant")) askClaude(apiKey, system, history)
        else askGemini(apiKey, system, history)

    private fun post(url: String, headers: Map<String, String>, body: JSONObject): String {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.setRequestProperty("content-type", "application/json")
        for ((k, v) in headers) conn.setRequestProperty(k, v)
        conn.connectTimeout = 10000
        conn.readTimeout = 60000
        conn.doOutput = true
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        if (code !in 200..299) throw RuntimeException("Error $code: ${text.take(300)}")
        return text
    }

    private fun askClaude(apiKey: String, system: String, history: List<Pair<String, String>>): String {
        val msgs = JSONArray()
        for ((role, content) in history) {
            msgs.put(JSONObject().put("role", role).put("content", content))
        }
        val body = JSONObject()
            .put("model", CLAUDE_MODEL)
            .put("max_tokens", 600)
            .put("system", system)
            .put("messages", msgs)
        val text = post(
            "https://api.anthropic.com/v1/messages",
            mapOf("x-api-key" to apiKey, "anthropic-version" to "2023-06-01"),
            body
        )
        val content = JSONObject(text).getJSONArray("content")
        val sb = StringBuilder()
        for (i in 0 until content.length()) {
            val block = content.getJSONObject(i)
            if (block.optString("type") == "text") sb.append(block.getString("text"))
        }
        return sb.toString()
    }

    private fun askGemini(apiKey: String, system: String, history: List<Pair<String, String>>): String {
        val contents = JSONArray()
        for ((role, content) in history) {
            contents.put(
                JSONObject()
                    .put("role", if (role == "assistant") "model" else "user")
                    .put("parts", JSONArray().put(JSONObject().put("text", content)))
            )
        }
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("contents", contents)
            .put(
                "generationConfig", JSONObject()
                    .put("maxOutputTokens", 2048)
                    .put("responseMimeType", "application/json")
                    .put("thinkingConfig", JSONObject().put("thinkingLevel", "low"))
            )
        val text = post(
            "https://generativelanguage.googleapis.com/v1beta/models/$GEMINI_MODEL:generateContent",
            mapOf("x-goog-api-key" to apiKey),
            body
        )
        val candidates = JSONObject(text).optJSONArray("candidates")
        if (candidates == null || candidates.length() == 0) throw RuntimeException("Gemini no devolvió respuesta")
        val parts = candidates.getJSONObject(0).getJSONObject("content").getJSONArray("parts")
        val sb = StringBuilder()
        for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
        return sb.toString()
    }
}
