package com.jarvis.assistant

import org.json.JSONObject

/** Órdenes simples que se ejecutan al instante, sin esperar a la IA. */
object LocalCommands {

    private val openRe = Regex("^(abre|abrir|ábreme|abreme|inicia|lanza|ejecuta)\\s+(?:la app de |la aplicación de |la aplicacion de |la app |el |la |los |las )?(.+)$")
    private val searchRe = Regex("^(busca|buscar|googlea|investiga)\\s+(?:en google\\s+|en internet\\s+)?(.+)$")
    private val timeRe = Regex("(\\d{1,2})(?:[:.](\\d{2}))?")
    private val durRe = Regex("(\\d+)\\s*(segundos?|minutos?|min|horas?)")
    private val volUp = Regex("(sube|subir|aumenta|más|mas).*volumen|volumen.*(arriba|más|mas)")
    private val volDown = Regex("(baja|bajar|reduce|menos).*volumen|volumen.*(abajo|menos)")

    /** Devuelve lo que D debe decir, o null si hay que preguntarle a la IA. */
    fun tryRun(raw: String, phone: PhoneActions): String? {
        val t = raw.lowercase().trim().trim('.', '!', '?', ',', ' ')

        fun run(vararg kv: Pair<String, Any>): String {
            val o = JSONObject()
            for ((k, v) in kv) o.put(k, v)
            return phone.run(o)
        }

        when {
            t in listOf("atrás", "atras", "vuelve", "volver", "ve atrás", "ve atras") -> {
                run("type" to "back"); return "Listo"
            }
            t in listOf("inicio", "ve al inicio", "ir al inicio", "pantalla de inicio", "home") -> {
                run("type" to "home"); return "Listo"
            }
            t.contains("linterna") -> {
                val state = when {
                    Regex("apag|desactiv|quita").containsMatchIn(t) -> "off"
                    Regex("enciend|prend|activ|pon").containsMatchIn(t) -> "on"
                    else -> "toggle"
                }
                return run("type" to "flashlight", "state" to state)
            }
            volUp.containsMatchIn(t) -> { run("type" to "volume", "dir" to "up"); return "Volumen arriba" }
            volDown.containsMatchIn(t) -> { run("type" to "volume", "dir" to "down"); return "Volumen abajo" }
            t.contains("alarma") -> {
                val m = timeRe.find(t.substringAfter("alarma")) ?: return null
                var h = m.groupValues[1].toInt()
                var min = m.groupValues[2].ifEmpty { "0" }.toInt()
                if (t.contains("y media")) min = 30
                val pm = t.contains("tarde") || t.contains("noche") || t.contains("pm") || t.contains("p.m")
                if (pm && h < 12) h += 12
                if (t.contains("noche") && h == 12) h = 0
                if (h > 23 || min > 59) return null
                run("type" to "alarm", "hour" to h, "minute" to min, "label" to "D")
                return "Alarma a las %02d:%02d".format(h, min)
            }
            t.contains("temporizador") || t.contains("cuenta regresiva") -> {
                val m = durRe.find(t) ?: return null
                val n = m.groupValues[1].toInt()
                val u = m.groupValues[2]
                val secs = when {
                    u.startsWith("seg") -> n
                    u.startsWith("min") -> n * 60
                    else -> n * 3600
                }
                run("type" to "timer", "seconds" to secs)
                return "Temporizador listo"
            }
        }

        searchRe.find(t)?.let {
            run("type" to "search", "query" to it.groupValues[2])
            return "Buscando"
        }
        openRe.find(t)?.let {
            val name = it.groupValues[2]
            val r = run("type" to "open_app", "name" to name)
            if (r.startsWith("abierta")) return "Abriendo $name"
        }
        return null
    }
}
