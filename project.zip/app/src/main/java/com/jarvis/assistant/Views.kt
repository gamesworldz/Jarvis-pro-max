package com.jarvis.assistant

import android.content.Context
import android.graphics.Camera
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import java.util.Random
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/** Esfera 3D decorativa: cambia de color y de energía según lo que hace D. */
class OrbView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : View(ctx, attrs) {

    enum class State { IDLE, LISTENING, THINKING, SPEAKING }

    @Volatile var state = State.IDLE
    @Volatile var level = 0f

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val cam = Camera()
    private val m = Matrix()
    private val oval = RectF()
    private val t0 = System.nanoTime()
    private var last = t0
    private var energy = 0.25f
    private var spin = 0.6f
    private var rip = 0f
    private var angle = 0f
    private var tiltX = 0f
    private var tiltY = 0f
    private var tx = 0f
    private var ty = 0f
    private var press = 0f
    private var pressT = 0f
    private var col = 0xFF00E5FF.toInt()
    private var col2 = 0xFF7C4DFF.toInt()

    init {
        isClickable = true // solo para inclinarse con el dedo; no activa nada
    }

    private fun al(c: Int, f: Float): Int = (c and 0x00FFFFFF) or ((f.coerceIn(0f, 1f) * 255).toInt() shl 24)

    private fun mix(a: Int, b: Int, f: Float): Int {
        val r = (Color.red(a) + (Color.red(b) - Color.red(a)) * f + 0.5f).toInt()
        val g = (Color.green(a) + (Color.green(b) - Color.green(a)) * f + 0.5f).toInt()
        val bl = (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * f + 0.5f).toInt()
        return Color.rgb(r.coerceIn(0, 255), g.coerceIn(0, 255), bl.coerceIn(0, 255))
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        last = System.nanoTime()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                tx = ((e.y - height / 2f) / (height / 2f)).coerceIn(-1f, 1f) * -28f
                ty = ((e.x - width / 2f) / (width / 2f)).coerceIn(-1f, 1f) * 28f
                pressT = 1f
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                tx = 0f; ty = 0f; pressT = 0f
            }
        }
        return super.onTouchEvent(e)
    }

    override fun onDraw(c: Canvas) {
        val now = System.nanoTime()
        val dt = ((now - last) / 1e9f).coerceAtMost(0.05f)
        last = now
        val t = (now - t0) / 1e9f
        val d = resources.displayMetrics.density

        val tE: Float; val tS: Float; val tR: Float; val tC: Int; val tC2: Int
        when (state) {
            State.IDLE -> { tE = 0.25f; tS = 0.6f; tR = 0f; tC = 0xFF00E5FF.toInt(); tC2 = 0xFF7C4DFF.toInt() }
            State.LISTENING -> { tE = 0.55f + level * 0.45f; tS = 1.4f; tR = 1f; tC = 0xFF3DFFB0.toInt(); tC2 = 0xFF00B3FF.toInt() }
            State.THINKING -> { tE = 0.7f; tS = 4.5f; tR = 0f; tC = 0xFFB388FF.toInt(); tC2 = 0xFF00E5FF.toInt() }
            State.SPEAKING -> { tE = 0.6f + 0.25f * (0.5f + 0.5f * sin(t * 9f)); tS = 1.8f; tR = 1f; tC = 0xFF40C4FF.toInt(); tC2 = 0xFFFFB74D.toInt() }
        }
        energy += (tE - energy) * min(1f, dt * 6f)
        spin += (tS - spin) * min(1f, dt * 3f)
        rip += (tR - rip) * min(1f, dt * 4f)
        angle += dt * 60f * spin
        tiltX += (tx - tiltX) * min(1f, dt * 8f)
        tiltY += (ty - tiltY) * min(1f, dt * 8f)
        press += (pressT - press) * min(1f, dt * 14f)
        val kc = min(1f, dt * 4f)
        col = mix(col, tC, kc)
        col2 = mix(col2, tC2, kc)

        val cx = width / 2f
        val cy = height / 2f
        val r0 = min(width, height) / 2f * 0.95f
        val coreR = r0 * 0.40f * (1f - 0.06f * press) * (1f + 0.07f * energy * sin(t * (3f + 7f * energy)))

        c.save()
        c.translate(0f, sin(t * 1.2f) * 3f * d) // flotando

        // Resplandor
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(
            cx, cy, r0,
            intArrayOf(al(col, 0.45f * energy + 0.1f), al(col2, 0.2f * energy), al(col2, 0f)),
            floatArrayOf(0.3f, 0.65f, 1f), Shader.TileMode.CLAMP
        )
        c.drawCircle(cx, cy, r0, p)
        p.shader = null

        // Ondas
        if (rip > 0.02f) {
            p.style = Paint.Style.STROKE
            p.strokeWidth = 2f * d
            for (i in 0..2) {
                val ph = (t * 0.7f + i / 3f) % 1f
                val rr = coreR * 1.2f + ph * (r0 - coreR * 1.2f)
                p.color = al(col, (1f - ph) * 0.55f * rip)
                c.drawCircle(cx, cy, rr, p)
            }
        }

        // Anillos en 3D
        cam.save()
        cam.setLocation(0f, 0f, -(r0 * 5f / 72f))
        cam.rotateX(tiltX + 16f * sin(t * 0.6f))
        cam.rotateY(tiltY + 16f * cos(t * 0.45f))
        cam.getMatrix(m)
        cam.restore()
        m.preTranslate(-cx, -cy)
        m.postTranslate(cx, cy)
        c.save()
        c.concat(m)
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        val radii = floatArrayOf(0.97f, 0.80f, 0.64f)
        val widths = floatArrayOf(3f, 5f, 3f)
        for (k in 0..2) {
            val r = r0 * radii[k]
            val cc = if (k == 1) col2 else col
            oval.set(cx - r, cy - r, cx + r, cy + r)
            p.strokeWidth = widths[k] * d
            p.color = al(cc, 0.15f)
            c.drawCircle(cx, cy, r, p)
            p.color = al(cc, 0.55f + 0.4f * energy)
            val base = angle * (if (k == 1) -1f else 1f) * (1f + k * 0.5f)
            for (s in 0..2) c.drawArc(oval, base + s * 120f, 55f + 10f * k, false, p)
        }
        c.restore()

        // Esfera central con volumen
        val ccx = cx + tiltY * 0.3f * d
        val ccy = cy - tiltX * 0.3f * d
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(
            ccx - coreR * 0.35f, ccy - coreR * 0.4f, coreR * 1.5f,
            intArrayOf(mix(col, Color.WHITE, 0.85f), mix(col, Color.WHITE, 0.1f), mix(col, Color.BLACK, 0.45f), mix(col, Color.BLACK, 0.8f)),
            floatArrayOf(0f, 0.25f, 0.65f, 1f), Shader.TileMode.CLAMP
        )
        c.drawCircle(ccx, ccy, coreR, p)
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2f * d
        p.color = al(col, 0.5f + 0.4f * energy)
        c.drawCircle(ccx, ccy, coreR, p)
        p.style = Paint.Style.FILL
        p.color = al(Color.WHITE, 0.35f)
        oval.set(ccx - coreR * 0.55f, ccy - coreR * 0.72f, ccx - coreR * 0.05f, ccy - coreR * 0.42f)
        c.drawOval(oval, p)

        // Puntos orbitando mientras piensa
        if (state == State.THINKING) {
            for (i in 0 until 8) {
                val a = Math.toRadians((angle * 3f + i * 45f).toDouble())
                val rr = coreR * 1.3f
                p.color = al(Color.WHITE, 0.25f + 0.75f * (i / 7f))
                c.drawCircle(
                    ccx + (cos(a) * rr).toFloat(), ccy + (sin(a) * rr).toFloat(),
                    (2f + i * 0.35f) * d, p
                )
            }
        }
        c.restore()
        postInvalidateOnAnimation()
    }
}

/** Fondo de partículas flotando con efecto de profundidad. */
class StarsView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : View(ctx, attrs) {
    private val rnd = Random(7)
    private val n = 36
    private val sx = FloatArray(n) { rnd.nextFloat() }
    private val sy = FloatArray(n) { rnd.nextFloat() }
    private val sz = FloatArray(n) { 0.3f + rnd.nextFloat() * 0.7f }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var last = System.nanoTime()

    override fun onDraw(c: Canvas) {
        val now = System.nanoTime()
        val dt = ((now - last) / 1e9f).coerceAtMost(0.05f)
        last = now
        val d = resources.displayMetrics.density
        for (i in 0 until n) {
            sy[i] -= dt * 0.02f * sz[i]
            if (sy[i] < -0.02f) {
                sy[i] = 1.02f
                sx[i] = rnd.nextFloat()
            }
            val tw = 0.5f + 0.5f * sin(now / 1e9f * (1f + sz[i] * 2f) + i)
            p.color = Color.argb((60 + 140 * tw * sz[i]).toInt().coerceIn(0, 255), 120, 230, 255)
            c.drawCircle(sx[i] * width, sy[i] * height, (0.8f + 2f * sz[i]) * d, p)
        }
        postInvalidateOnAnimation()
    }
}
