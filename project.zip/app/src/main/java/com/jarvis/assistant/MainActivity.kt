package com.jarvis.assistant

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

private val SYSTEM = """
Eres Jarvis, un asistente de voz que controla un teléfono Android. Hablas en el idioma del usuario y eres breve.
Responde SIEMPRE y SOLO con un objeto JSON, sin texto fuera de él y sin bloques de código:
{"say":"frase corta para decir en voz alta","actions":[...],"continue":false}

Acciones disponibles (cada una es un objeto con "type"):
- {"type":"open_app","name":"WhatsApp"}
- {"type":"call","number":"123456789"} (abre el marcador)
- {"type":"sms","number":"123456789","text":"hola"} (deja el mensaje preparado)
- {"type":"alarm","hour":7,"minute":30,"label":"Despertar"}
- {"type":"timer","seconds":300}
- {"type":"open_url","url":"https://..."}
- {"type":"search","query":"texto"}
- {"type":"navigate","place":"lugar o dirección"}
- {"type":"tap","text":"texto visible del botón"}
- {"type":"type","text":"texto a escribir en el campo activo"}
- {"type":"enter"}
- {"type":"scroll_down"} y {"type":"scroll_up"}
- {"type":"back"}, {"type":"home"}, {"type":"recents"}
- {"type":"wait","ms":1500}

Pon "continue":true cuando necesites ver la pantalla después de tus acciones para seguir
(por ejemplo, abrir una app y luego tocar un botón). Recibirás los resultados y la lista de textos en pantalla.
Cuando termines, pon "continue":false. Nunca inventes textos de pantalla: toca solo lo que veas.
Para acciones delicadas (enviar mensajes, pagos, borrar cosas, llamadas) primero pregunta confirmación:
responde solo con "say" preguntando y "actions":[].
""".trimIndent()

class MainActivity : Activity(), TextToSpeech.OnInitListener {

    private lateinit var status: TextView
    private lateinit var log: TextView
    private lateinit var scroll: ScrollView
    private lateinit var keyInput: EditText
    private lateinit var textInput: EditText
    private lateinit var phone: PhoneActions
    private var tts: TextToSpeech? = null
    private var recognizer: SpeechRecognizer? = null
    private val history = mutableListOf<Pair<String, String>>()

    @Volatile
    private var busy = false

    private fun prefs(): SharedPreferences = getSharedPreferences("jarvis", Context.MODE_PRIVATE)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        status = findViewById(R.id.status)
        log = findViewById(R.id.log)
        scroll = findViewById(R.id.scroll)
        keyInput = findViewById(R.id.keyInput)
        textInput = findViewById(R.id.textInput)
        phone = PhoneActions(applicationContext)
        tts = TextToSpeech(this, this)

        findViewById<Button>(R.id.saveKey).setOnClickListener {
            val k = keyInput.text.toString().trim()
            if (k.isNotEmpty()) {
                prefs().edit().putString("key", k).apply()
                keyInput.setText("")
                addLog("Clave guardada.")
                updateStatus()
            }
        }
        findViewById<Button>(R.id.accBtn).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        findViewById<Button>(R.id.sendBtn).setOnClickListener {
            val t = textInput.text.toString().trim()
            if (t.isNotEmpty()) {
                textInput.setText("")
                process(t)
            }
        }
        findViewById<Button>(R.id.micBtn).setOnClickListener { startListening() }
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    override fun onDestroy() {
        tts?.shutdown()
        recognizer?.destroy()
        super.onDestroy()
    }

    override fun onInit(code: Int) {
        if (code == TextToSpeech.SUCCESS) tts?.language = Locale.getDefault()
    }

    private fun updateStatus() {
        val acc = JarvisAccessibilityService.instance != null
        val hasKey = !prefs().getString("key", "").isNullOrBlank()
        status.text = "Accesibilidad: " + (if (acc) "activa ✅" else "desactivada ❌") +
            "   |   Clave: " + (if (hasKey) "guardada ✅" else "falta ❌")
    }

    private fun addLog(msg: String) {
        runOnUiThread {
            log.append(msg + "\n\n")
            scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
        }
    }

    private fun speak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    // ---------- Voz ----------

    private fun startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            addLog("Este móvil no tiene reconocimiento de voz disponible.")
            return
        }
        tts?.stop()
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
            override fun onError(error: Int) {
                addLog("No te entendí (código $error). Prueba otra vez.")
            }
            override fun onResults(results: Bundle?) {
                val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!t.isNullOrBlank()) process(t)
            }
        })
        recognizer = r
        r.startListening(
            Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
        )
        addLog("🎤 Escuchando…")
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startListening()
        }
    }

    // ---------- Cerebro ----------

    private fun trimHistory() {
        while (history.isNotEmpty() && (history.size > 20 || history.first().first != "user")) {
            history.removeAt(0)
        }
    }

    private fun process(text: String) {
        val key = prefs().getString("key", "") ?: ""
        if (key.isBlank()) {
            addLog("Primero pega tu clave API de Anthropic y pulsa Guardar.")
            return
        }
        if (busy) return
        busy = true
        addLog("Tú: $text")

        Thread {
            try {
                history.add("user" to text)
                var steps = 0
                while (steps < 6) {
                    steps++
                    trimHistory()
                    val raw = ClaudeClient.ask(key, SYSTEM, history)
                    history.add("assistant" to raw)

                    var say = raw
                    var actions = JSONArray()
                    var cont = false
                    try {
                        val j = JSONObject(raw.substring(raw.indexOf('{'), raw.lastIndexOf('}') + 1))
                        say = j.optString("say")
                        actions = j.optJSONArray("actions") ?: JSONArray()
                        cont = j.optBoolean("continue", false)
                    } catch (e: Exception) {
                        // Si no vino JSON, se muestra el texto tal cual.
                    }

                    if (say.isNotBlank()) {
                        addLog("Jarvis: $say")
                        speak(say)
                    }

                    val results = StringBuilder()
                    for (i in 0 until actions.length()) {
                        val a = actions.getJSONObject(i)
                        results.append(a.optString("type")).append(": ").append(phone.run(a)).append('\n')
                    }

                    if (!cont || actions.length() == 0) break
                    Thread.sleep(1500)
                    val screen = JarvisAccessibilityService.instance?.screenText()
                        ?: "(accesibilidad desactivada, no puedo ver la pantalla)"
                    history.add("user" to "Resultados:\n$results\nPantalla actual:\n$screen")
                }
            } catch (e: Exception) {
                addLog("Error: ${e.message}")
                if (history.lastOrNull()?.first == "user") history.removeAt(history.size - 1)
            } finally {
                busy = false
            }
        }.start()
    }
}
