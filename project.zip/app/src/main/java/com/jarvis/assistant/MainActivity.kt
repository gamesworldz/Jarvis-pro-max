package com.jarvis.assistant

import android.Manifest
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.OvershootInterpolator
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {

    companion object {
        const val USER = 0
        const val JARVIS = 1
        const val SYS = 2
        const val IDLE_TEXT = "Toca 🎤 para hablar"
        val GREEN = 0xFF3DFFB0.toInt()
        val RED = 0xFFFF5C7A.toInt()
    }

    private lateinit var chipAcc: TextView
    private lateinit var chipKey: TextView
    private lateinit var chat: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var panel: View
    private lateinit var keyInput: EditText
    private lateinit var textInput: EditText
    private lateinit var orb: OrbView
    private lateinit var orbLabel: TextView
    private lateinit var actionBtn: Button
    private lateinit var phone: PhoneActions
    private var tts: TextToSpeech? = null
    private var recognizer: SpeechRecognizer? = null
    private var typing: TextView? = null
    private var typingAnim: ObjectAnimator? = null
    private val history = mutableListOf<Pair<String, String>>()

    @Volatile private var busy = false
    @Volatile private var speaking = false
    @Volatile private var listening = false

    private fun prefs(): SharedPreferences = getSharedPreferences("jarvis", Context.MODE_PRIVATE)
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = 0xFF0B1736.toInt()
        window.navigationBarColor = 0xFF03050C.toInt()
        setContentView(R.layout.activity_main)

        chipAcc = findViewById(R.id.chipAcc)
        chipKey = findViewById(R.id.chipKey)
        chat = findViewById(R.id.chat)
        scroll = findViewById(R.id.scroll)
        panel = findViewById(R.id.panel)
        keyInput = findViewById(R.id.keyInput)
        textInput = findViewById(R.id.textInput)
        orb = findViewById(R.id.orb)
        orbLabel = findViewById(R.id.orbLabel)
        actionBtn = findViewById(R.id.actionBtn)
        phone = PhoneActions(applicationContext)
        tts = TextToSpeech(this, this)
        orbLabel.text = IDLE_TEXT

        val gear = findViewById<Button>(R.id.gearBtn)
        val save = findViewById<Button>(R.id.saveKey)
        val acc = findViewById<Button>(R.id.accBtn)
        for (b in listOf(gear, save, acc, actionBtn)) b.pressable()

        gear.setOnClickListener {
            gear.animate().rotationBy(180f).setDuration(350).start()
            togglePanel()
        }
        save.setOnClickListener {
            val k = keyInput.text.toString().trim()
            if (k.isNotEmpty()) {
                prefs().edit().putString("key", k).apply()
                keyInput.setText("")
                addBubble("Clave guardada ✔", SYS)
                updateStatus()
                togglePanel()
            }
        }
        acc.setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }

        actionBtn.setOnClickListener {
            when {
                listening -> cancelListening()
                textInput.text.isNotBlank() -> sendTyped()
                else -> startListening()
            }
        }
        textInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { updateActionBtn() }
        })
        textInput.setOnEditorActionListener { _, id, _ ->
            if (id == EditorInfo.IME_ACTION_SEND) { sendTyped(); true } else false
        }

        if (prefs().getString("key", "").isNullOrBlank()) panel.visibility = View.VISIBLE
        if (!prefs().getBoolean("asked", false)) {
            prefs().edit().putBoolean("asked", true).apply()
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS), 2)
        }

        buildChips()
        updateActionBtn()
        addBubble("Hola, soy D. Pulsa 🎤 y dime qué hacer.", JARVIS)
        intro()
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    override fun onDestroy() {
        tts?.shutdown()
        recognizer?.destroy()
        super.onDestroy()
    }

    override fun onInit(code: Int) {
        if (code == TextToSpeech.SUCCESS) {
            tts?.language = Locale.getDefault()
            tts?.setSpeechRate(1.1f)
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) { speakingDone() }
                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) { speakingDone() }
            })
        }
    }

    private fun speakingDone() {
        speaking = false
        if (busy) setOrb(OrbView.State.THINKING, "Pensando…") else setOrb(OrbView.State.IDLE, IDLE_TEXT)
    }

    // ---------- Interfaz dinámica ----------

    @SuppressLint("ClickableViewAccessibility")
    private fun View.pressable() {
        setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    v.animate().scaleX(0.94f).scaleY(0.94f).setDuration(90).start()
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    v.animate().scaleX(1f).scaleY(1f).setDuration(260)
                        .setInterpolator(OvershootInterpolator(3f)).start()
            }
            false
        }
    }

    private fun buildChips() {
        val row = findViewById<LinearLayout>(R.id.chipsRow)
        val items = listOf(
            "🔦 Linterna" to """{"type":"flashlight","state":"toggle"}""",
            "🔊 Subir" to """{"type":"volume","dir":"up"}""",
            "🔉 Bajar" to """{"type":"volume","dir":"down"}""",
            "🏠 Inicio" to """{"type":"home"}""",
            "◀ Atrás" to """{"type":"back"}""",
            "📷 Cámara" to """{"type":"camera"}""",
            "📶 Wi-Fi" to """{"type":"settings","name":"wifi"}"""
        )
        for ((i, item) in items.withIndex()) {
            val tv = TextView(this)
            tv.text = item.first
            tv.setTextColor(Color.WHITE)
            tv.textSize = 14f
            tv.setBackgroundResource(R.drawable.bg_chip)
            tv.setPadding(dp(16), dp(12), dp(16), dp(12))
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.marginEnd = dp(8)
            tv.layoutParams = lp
            tv.pressable()
            tv.setOnClickListener {
                val res = phone.run(JSONObject(item.second))
                if (res != "ok") Toast.makeText(this, res, Toast.LENGTH_SHORT).show()
            }
            tv.alpha = 0f
            tv.translationX = dp(30).toFloat()
            tv.animate().alpha(1f).translationX(0f).setStartDelay(500L + i * 70L).setDuration(400)
                .setInterpolator(OvershootInterpolator(1.2f)).start()
            row.addView(tv)
        }
    }

    private fun intro() {
        fun View.rise(fromY: Float, delay: Long) {
            alpha = 0f
            translationY = fromY
            animate().alpha(1f).translationY(0f).setStartDelay(delay).setDuration(650)
                .setInterpolator(OvershootInterpolator(1.0f)).start()
        }
        findViewById<View>(R.id.header).rise(-dp(40).toFloat(), 0)
        findViewById<View>(R.id.inputRow).rise(dp(80).toFloat(), 250)
        orb.scaleX = 0f
        orb.scaleY = 0f
        orb.alpha = 0f
        orb.animate().scaleX(1f).scaleY(1f).alpha(1f).setStartDelay(150).setDuration(1000)
            .setInterpolator(OvershootInterpolator(2.2f)).start()
    }

    private fun togglePanel() {
        if (panel.visibility == View.VISIBLE) {
            panel.animate().alpha(0f).translationY(-dp(16).toFloat()).setDuration(200)
                .withEndAction { panel.visibility = View.GONE }.start()
        } else {
            panel.alpha = 0f
            panel.translationY = -dp(16).toFloat()
            panel.visibility = View.VISIBLE
            panel.animate().alpha(1f).translationY(0f).setDuration(260).start()
        }
    }

    private fun updateActionBtn() {
        runOnUiThread {
            val hasText = textInput.text.isNotBlank()
            val label = if (listening) "■" else if (hasText) "➤" else "🎤"
            val bg = if (listening) R.drawable.btn_stop else R.drawable.btn_send
            if (actionBtn.text.toString() != label) {
                actionBtn.text = label
                actionBtn.setBackgroundResource(bg)
                actionBtn.scaleX = 0.7f
                actionBtn.scaleY = 0.7f
                actionBtn.animate().scaleX(1f).scaleY(1f).setDuration(260)
                    .setInterpolator(OvershootInterpolator(3f)).start()
            }
        }
    }

    private fun setOrb(s: OrbView.State, label: String) {
        runOnUiThread {
            orb.state = s
            orbLabel.text = label
            orbLabel.alpha = 0f
            orbLabel.animate().alpha(1f).setDuration(250).start()
        }
    }

    private fun updateStatus() {
        val acc = JarvisAccessibilityService.instance != null
        val hasKey = !prefs().getString("key", "").isNullOrBlank()
        chipAcc.text = if (acc) "● Accesibilidad" else "● Accesibilidad apagada"
        chipAcc.setTextColor(if (acc) GREEN else RED)
        chipKey.text = if (hasKey) "● Clave" else "● Falta clave"
        chipKey.setTextColor(if (hasKey) GREEN else RED)
    }

    private fun addBubble(text: String, kind: Int) {
        runOnUiThread {
            val tv = TextView(this)
            tv.text = text
            tv.setTextColor(Color.WHITE)
            tv.textSize = 15f
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.setMargins(0, dp(5), 0, dp(5))
            when (kind) {
                USER -> {
                    tv.setBackgroundResource(R.drawable.bubble_user)
                    lp.gravity = Gravity.END
                    lp.marginStart = dp(48)
                }
                JARVIS -> {
                    tv.setBackgroundResource(R.drawable.bubble_jarvis)
                    lp.gravity = Gravity.START
                    lp.marginEnd = dp(48)
                }
                else -> {
                    tv.textSize = 12f
                    tv.setTextColor(0x99FFFFFF.toInt())
                    lp.gravity = Gravity.CENTER_HORIZONTAL
                }
            }
            tv.setPadding(dp(14), dp(10), dp(14), dp(10))
            tv.layoutParams = lp
            tv.alpha = 0f
            tv.translationY = dp(24).toFloat()
            tv.scaleX = 0.92f
            tv.scaleY = 0.92f
            chat.addView(tv)
            tv.animate().alpha(1f).translationY(0f).scaleX(1f).scaleY(1f).setDuration(380)
                .setInterpolator(OvershootInterpolator(1.1f)).start()
            scroll.postDelayed({ scroll.smoothScrollTo(0, chat.bottom) }, 80)
        }
    }

    private fun showTyping() {
        runOnUiThread {
            if (typing != null) return@runOnUiThread
            val tv = TextView(this)
            tv.text = "● ● ●"
            tv.setTextColor(0xFF00E5FF.toInt())
            tv.textSize = 14f
            tv.setBackgroundResource(R.drawable.bubble_jarvis)
            tv.setPadding(dp(16), dp(10), dp(16), dp(10))
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.setMargins(0, dp(5), 0, dp(5))
            lp.gravity = Gravity.START
            tv.layoutParams = lp
            chat.addView(tv)
            val anim = ObjectAnimator.ofFloat(tv, "alpha", 1f, 0.25f)
            anim.duration = 450
            anim.repeatCount = ValueAnimator.INFINITE
            anim.repeatMode = ValueAnimator.REVERSE
            anim.start()
            typingAnim = anim
            typing = tv
            scroll.postDelayed({ scroll.smoothScrollTo(0, chat.bottom) }, 80)
        }
    }

    private fun hideTyping() {
        runOnUiThread {
            typingAnim?.cancel()
            typingAnim = null
            typing?.let { chat.removeView(it) }
            typing = null
        }
    }

    private fun speak(text: String) {
        speaking = true
        setOrb(OrbView.State.SPEAKING, "Hablando…")
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    private fun sendTyped() {
        val t = textInput.text.toString().trim()
        if (t.isNotEmpty()) {
            textInput.setText("")
            process(t)
        }
    }

    // ---------- Voz ----------

    private fun cancelListening() {
        recognizer?.cancel()
        listening = false
        orb.level = 0f
        setOrb(OrbView.State.IDLE, IDLE_TEXT)
        updateActionBtn()
    }

    private fun startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            addBubble("Este móvil no tiene reconocimiento de voz disponible.", SYS)
            return
        }
        tts?.stop()
        speaking = false
        recognizer?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {
                orb.level = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
            }
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
            override fun onError(error: Int) {
                if (!listening) return
                listening = false
                orb.level = 0f
                setOrb(OrbView.State.IDLE, IDLE_TEXT)
                updateActionBtn()
                if (error != SpeechRecognizer.ERROR_CLIENT) {
                    addBubble("No te entendí. Prueba otra vez.", SYS)
                }
            }
            override fun onResults(results: Bundle?) {
                listening = false
                orb.level = 0f
                updateActionBtn()
                val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!t.isNullOrBlank()) process(t) else setOrb(OrbView.State.IDLE, IDLE_TEXT)
            }
        })
        recognizer = r
        listening = true
        updateActionBtn()
        r.startListening(
            Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toLanguageTag())
        )
        setOrb(OrbView.State.LISTENING, "Escuchando…")
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startListening()
        }
    }

    // ---------- Cerebro ----------

    private fun trimHistory() {
        while (history.isNotEmpty() && (history.size > 16 || history.first().first != "user")) {
            history.removeAt(0)
        }
    }

    private fun process(text: String) {
        if (busy) return

        // Órdenes simples: se ejecutan al instante, sin IA
        val local = LocalCommands.tryRun(text, phone)
        if (local != null) {
            addBubble(text, USER)
            addBubble(local, JARVIS)
            speak(local)
            return
        }

        val key = prefs().getString("key", "") ?: ""
        if (key.isBlank()) {
            addBubble("Primero pega tu clave API en ⚙ y pulsa Guardar.", SYS)
            runOnUiThread { if (panel.visibility != View.VISIBLE) togglePanel() }
            setOrb(OrbView.State.IDLE, IDLE_TEXT)
            return
        }
        busy = true
        addBubble(text, USER)
        setOrb(OrbView.State.THINKING, "Pensando…")

        Thread {
            try {
                history.add("user" to text)
                var steps = 0
                while (steps < 6) {
                    steps++
                    trimHistory()
                    showTyping()
                    val raw = ClaudeClient.ask(key, SYSTEM, history)
                    hideTyping()
                    history.add("assistant" to raw)

                    var say = raw
                    var actions = JSONArray()
                    var cont = false
                    try {
                        val j = JSONObject(raw.substring(raw.indexOf('{'), raw.lastIndexOf('}') + 1))
                        say = j.optString("say")
                        actions = j.optJSONArray("actions") ?: JSONArray()
                        cont = j.optBoolean("continue", false)
                    } catch (e: Exception) {
                        // Si no vino JSON, se muestra el texto tal cual.
                    }

                    if (say.isNotBlank()) {
                        addBubble(say, JARVIS)
                        speak(say)
                    }

                    val results = StringBuilder()
                    for (i in 0 until actions.length()) {
                        val a = actions.getJSONObject(i)
                        results.append(a.optString("type")).append(": ").append(phone.run(a)).append('\n')
                    }

                    if (!cont || actions.length() == 0) break
                    Thread.sleep(900)
                    val screen = JarvisAccessibilityService.instance?.screenText()
                        ?: "(accesibilidad desactivada, no puedo ver la pantalla)"
                    history.add("user" to "Resultados:\n$results\nPantalla actual:\n$screen")
                }
            } catch (e: Exception) {
                hideTyping()
                addBubble("⚠ ${e.message}", SYS)
                if (history.lastOrNull()?.first == "user") history.removeAt(history.size - 1)
            } finally {
                hideTyping()
                busy = false
                if (!speaking) setOrb(OrbView.State.IDLE, IDLE_TEXT)
            }
        }.start()
    }
}
