package com.jarvis.assistant

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock
import org.json.JSONObject

class PhoneActions(private val ctx: Context) {

    private fun start(i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    }

    private fun acc(block: (JarvisAccessibilityService) -> Boolean): String {
        val s = JarvisAccessibilityService.instance ?: return "accesibilidad desactivada"
        return if (block(s)) "ok" else "no se pudo"
    }

    fun run(a: JSONObject): String = try {
        exec(a)
    } catch (e: Exception) {
        "error: ${e.message}"
    }

    private fun exec(a: JSONObject): String {
        return when (a.optString("type")) {
            "open_app" -> openApp(a.getString("name"))
            "call" -> {
                start(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(a.getString("number")))))
                "marcador abierto"
            }
            "sms" -> {
                val i = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(a.getString("number"))))
                i.putExtra("sms_body", a.optString("text"))
                start(i)
                "mensaje preparado, falta pulsar enviar"
            }
            "alarm" -> {
                val i = Intent(AlarmClock.ACTION_SET_ALARM)
                    .putExtra(AlarmClock.EXTRA_HOUR, a.getInt("hour"))
                    .putExtra(AlarmClock.EXTRA_MINUTES, a.optInt("minute", 0))
                    .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label", "Jarvis"))
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                start(i)
                "alarma creada"
            }
            "timer" -> {
                val i = Intent(AlarmClock.ACTION_SET_TIMER)
                    .putExtra(AlarmClock.EXTRA_LENGTH, a.getInt("seconds"))
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                start(i)
                "temporizador creado"
            }
            "open_url" -> {
                start(Intent(Intent.ACTION_VIEW, Uri.parse(a.getString("url"))))
                "abierto"
            }
            "search" -> {
                start(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(a.getString("query")))))
                "búsqueda abierta"
            }
            "navigate" -> {
                start(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(a.getString("place")))))
                "mapa abierto"
            }
            "tap" -> acc { it.tapText(a.getString("text")) }
            "type" -> acc { it.typeText(a.getString("text")) }
            "enter" -> acc { it.pressEnter() }
            "scroll_down" -> acc { it.scroll(true) }
            "scroll_up" -> acc { it.scroll(false) }
            "back" -> acc { it.global(AccessibilityService.GLOBAL_ACTION_BACK) }
            "home" -> acc { it.global(AccessibilityService.GLOBAL_ACTION_HOME) }
            "recents" -> acc { it.global(AccessibilityService.GLOBAL_ACTION_RECENTS) }
            "wait" -> {
                Thread.sleep(a.optLong("ms", 1000).coerceIn(0L, 5000L))
                "ok"
            }
            else -> "acción desconocida"
        }
    }

    private fun openApp(name: String): String {
        val pm = ctx.packageManager
        val q = name.lowercase().trim()
        val apps = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
        )
        val match = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == q }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) }
            ?: return "no encontré la app '$name'"
        val launch = pm.getLaunchIntentForPackage(match.activityInfo.packageName)
            ?: return "no se pudo abrir '$name'"
        start(launch)
        return "abierta ${match.loadLabel(pm)}"
    }
}
