package com.jarvis.assistant

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import org.json.JSONObject

class PhoneActions(private val ctx: Context) {

    private var torchOn = false

    private fun start(i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    }

    private fun acc(block: (JarvisAccessibilityService) -> Boolean): String {
        val s = JarvisAccessibilityService.instance ?: return "accesibilidad desactivada"
        return if (block(s)) "ok" else "no se pudo"
    }

    fun run(a: JSONObject): String = try {
        exec(a)
    } catch (e: Exception) {
        "error: ${e.message}"
    }

    private fun exec(a: JSONObject): String {
        return when (a.optString("type")) {
            "open_app" -> openApp(a.getString("name"))
            "call" -> {
                start(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(a.getString("number")))))
                "marcador abierto"
            }
            "sms" -> {
                val i = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(a.getString("number"))))
                i.putExtra("sms_body", a.optString("text"))
                start(i)
                "mensaje preparado, falta pulsar enviar"
            }
            "call_contact" -> withContact(a.getString("name")) { who, num ->
                start(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(num))))
                "marcador abierto con $who"
            }
            "sms_contact" -> withContact(a.getString("name")) { who, num ->
                val i = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(num)))
                i.putExtra("sms_body", a.optString("text"))
                start(i)
                "mensaje para $who preparado, falta pulsar enviar"
            }
            "alarm" -> {
                val i = Intent(AlarmClock.ACTION_SET_ALARM)
                    .putExtra(AlarmClock.EXTRA_HOUR, a.getInt("hour"))
                    .putExtra(AlarmClock.EXTRA_MINUTES, a.optInt("minute", 0))
                    .putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label", "D"))
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                start(i)
                "alarma creada"
            }
            "timer" -> {
                val i = Intent(AlarmClock.ACTION_SET_TIMER)
                    .putExtra(AlarmClock.EXTRA_LENGTH, a.getInt("seconds"))
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                start(i)
                "temporizador creado"
            }
            "open_url" -> {
                start(Intent(Intent.ACTION_VIEW, Uri.parse(a.getString("url"))))
                "abierto"
            }
            "search" -> {
                start(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(a.getString("query")))))
                "búsqueda abierta"
            }
            "navigate" -> {
                start(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(a.getString("place")))))
                "mapa abierto"
            }
            "flashlight" -> torch(a.optString("state", "toggle"))
            "volume" -> volume(a.optString("dir", "up"))
            "camera" -> {
                start(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))
                "cámara abierta"
            }
            "settings" -> settings(a.optString("name", ""))
            "tap" -> acc { it.tapText(a.getString("text")) }
            "type" -> acc { it.typeText(a.getString("text")) }
            "enter" -> acc { it.pressEnter() }
            "scroll_down" -> acc { it.scroll(true) }
            "scroll_up" -> acc { it.scroll(false) }
            "back" -> acc { it.global(AccessibilityService.GLOBAL_ACTION_BACK) }
            "home" -> acc { it.global(AccessibilityService.GLOBAL_ACTION_HOME) }
            "recents" -> acc { it.global(AccessibilityService.GLOBAL_ACTION_RECENTS) }
            "wait" -> {
                Thread.sleep(a.optLong("ms", 1000).coerceIn(0L, 5000L))
                "ok"
            }
            else -> "acción desconocida"
        }
    }

    private fun torch(state: String): String {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return "este móvil no tiene linterna"
        torchOn = when (state) {
            "on" -> true
            "off" -> false
            else -> !torchOn
        }
        cm.setTorchMode(id, torchOn)
        return if (torchOn) "linterna encendida" else "linterna apagada"
    }

    private fun volume(dir: String): String {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.adjustStreamVolume(
            AudioManager.STREAM_MUSIC,
            if (dir == "down") AudioManager.ADJUST_LOWER else AudioManager.ADJUST_RAISE,
            AudioManager.FLAG_SHOW_UI
        )
        return if (dir == "down") "volumen bajado" else "volumen subido"
    }

    private fun settings(name: String): String {
        val action = when (name.lowercase()) {
            "wifi", "wi-fi" -> Settings.ACTION_WIFI_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "pantalla", "brillo" -> Settings.ACTION_DISPLAY_SETTINGS
            "sonido" -> Settings.ACTION_SOUND_SETTINGS
            "bateria", "batería" -> Settings.ACTION_BATTERY_SAVER_SETTINGS
            "ubicacion", "ubicación" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
            "apps", "aplicaciones" -> Settings.ACTION_APPLICATION_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        start(Intent(action))
        return "ajustes abiertos"
    }

    private fun withContact(name: String, block: (String, String) -> String): String {
        if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            return "falta el permiso de contactos"
        }
        var found: Pair<String, String>? = null
        val c = ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ),
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
            arrayOf("%$name%"),
            null
        )
        c?.use { if (it.moveToFirst()) found = Pair(it.getString(0), it.getString(1)) }
        val f = found ?: return "no encontré el contacto '$name'"
        return block(f.first, f.second)
    }

    private fun openApp(name: String): String {
        val pm = ctx.packageManager
        val q = name.lowercase().trim()
        val apps = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
        )
        val match = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == q }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) }
            ?: return "no encontré la app '$name'"
        val launch = pm.getLaunchIntentForPackage(match.activityInfo.packageName)
            ?: return "no se pudo abrir '$name'"
        start(launch)
        return "abierta ${match.loadLabel(pm)}"
    }
}
